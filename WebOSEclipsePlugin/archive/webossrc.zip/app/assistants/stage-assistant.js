function StageAssistant () {
}

StageAssistant.prototype.setup = function() {
   Mojo.Controller.stageController.pushScene ("first");
}