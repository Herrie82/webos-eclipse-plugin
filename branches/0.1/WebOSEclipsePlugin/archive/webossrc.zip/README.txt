=================
==    INFO     ==
=================

The webOS Eclipse Plug-in is design to speed the development of webOS applications.

=================
==  LEARN MORE ==
=================

Visit Palm preSchool @ http://www.palmpreschool.com to learn more about webOS applications, find tutorials and keep up with the latest webOS devices. 


=================
==  WHATS NEW  ==
=================

V1.0 - Create webOS project with sample application
